# MineMakers

An **experimental Minecraft: Java Edition ↔ Trailmakers bridge**, inspired by
[SkyCraft](https://github.com/chasmlol/SkyCraft). Minecraft runs alongside Trailmakers
and owns movement, inventory, combat rules, armor, blocks, TNT, ender pearls and game
modes. Trailmakers renders physical block proxies and a blocky player proxy.

**This is a compiled development prototype, not a finished playable crossover.**
The Fabric JAR builds and the protocol/adapter tests pass. The two games have not
been run together here. Native incoming weapon damage on custom blocks, accurate
terrain/contraption geometry, and auto-aim integration still require engine work.
There is no native Trailmakers plugin in this release.

## What is implemented

- Fabric mod for **Minecraft 1.21.1, Java 21, Fabric Loader 0.16.10+** and Fabric API.
- One integrated-singleplayer Minecraft session paired with Trailmakers player 0.
- Vanilla wooden, stone, iron, golden, diamond and netherite swords; bow/arrows;
  armor; ender pearls; TNT/flint and steel; wood, stone and bedrock. These are real
  vanilla items, supplied by `/minemakers starter`, not reimplementations.
- Vanilla survival/creative switching, flight and invulnerability on the Minecraft
  side. Creative invulnerability is also set on the paired Trailmakers player.
- Trailmakers physical cubes for nearby solid Minecraft blocks. Ten progressive
  crack overlays plus an undamaged texture. World persistence stays in Minecraft.
- A file bridge with handshake, bounded snapshots, stale-input release, acknowledged
  combat events and duplicate-hit prevention.
- Minecraft melee/projectile/TNT damage against invisible vanilla slime proxies
  representing nearby Trailmakers contraption blocks, forwarded to the native blocks
  with damage and impulse. Proxy geometry is approximate and needs in-game testing.
- Downward terrain samples mirrored as temporary Minecraft barriers so vanilla
  physics/projectiles have ground to collide with. This is a coarse heightfield.
- Accumulated incoming block-damage logic: resistance from hardness/blast resistance,
  no more than 35% total health removed per native hit, progressive cracks, eventual
  destruction, and unbreakable bedrock. **The native weapon detector that would feed
  this logic does not exist yet.** The Lua entry points are integration hooks only.

## What remains

| Requirement | Current limitation |
|---|---|
| Trailmakers guns progressively damage placed Minecraft blocks | Damage/crack pipeline implemented; stock Lua cannot observe those custom-object weapon hits. Needs native hook. |
| Native weapons damage Minecraft health with armor and knockback | No nonfatal native damage callback. Only a coarse native-death → Minecraft damage fallback exists; it cannot apply armor before native death. |
| Native auto-aim locks on Minecraft players | The existing native player is retained underneath the visual proxy. Target selection has not been verified; custom target registration is unavailable through documented Lua. |
| Accurate world collision | Ground is sampled; overhangs, caves, slopes, walls and fast-moving contraptions are not accurately mirrored. |
| Minecraft graphics in Trailmakers | Original cube textures and a static blocky avatar, not exported Minecraft skin/animations, held items or full HUD. |
| Multiplayer | One local pair only. No dedicated-server bridge, player mapping, replication or authoritative multiplayer validation. |
| SkyCraft-style automatic launch/hidden window | Launch Minecraft manually. No launcher/account integration or automatic hiding. Inventory/menus require switching to Minecraft. |

See [installation and controls](docs/INSTALL.md), [protocol/architecture](docs/ARCHITECTURE.md)
and the [in-game acceptance checklist](docs/ACCEPTANCE.md).

## Build and test

```sh
# JDK 21 with javac is required.
cd fabric
./gradlew --no-daemon build
cd ..
python3 -m venv .tools/test-venv
.tools/test-venv/bin/pip install -r tools/test-requirements.txt
.tools/test-venv/bin/python tools/test.py
python3 tools/package.py
```

Windows: use `gradlew.bat` and `.tools\test-venv\Scripts\python.exe` as appropriate.
The remapped mod is `fabric/build/libs/minemakers-fabric-0.1.0.jar`. The package tool
requires that JAR; `--source-only` explicitly creates a developer source bundle.
Do not mistake the `-sources.jar` for an installable mod.

The Lua test double validates our adapter contract; it cannot establish Trailmakers
physics, rendering, MoonSharp behavior or weapon behavior. The Gradle build has no
JUnit tests; the separately invoked test harness is the test evidence.

Development needs outbound access to Fabric/Minecraft repositories and Maven/Gradle.
Runtime uses only two local files in the Trailmakers mod's `data_dynamic` directory;
there is no bridge TCP listener and no secret or token requirement.

In this managed Linux workspace, `python3 tools/cloud_setup.py` additionally prepares
a checksum-verified JDK when needed, uses the existing system Java CA trust store and
managed HTTP proxy, builds the JAR, installs the pinned test dependency outside the
checkout, and runs the test harness. Normal local installations can use the manual
commands above. The Steam game itself is not installed in this cloud workspace.
